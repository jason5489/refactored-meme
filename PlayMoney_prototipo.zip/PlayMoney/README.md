# PlayMoney — protótipo inicial

## Como testar gratuitamente
1. Extraia o arquivo ZIP.
2. Abra `index.html` em um navegador moderno no celular ou computador.
3. Toque em **Testar missão** e depois em **Adicionar pontos**.
4. Veja o saldo e o número de missões concluídas atualizarem.
5. Use **Zerar demonstração** para reiniciar.

## O que funciona
- Interface responsiva para celular.
- Filtros por tipo de missão.
- Saldo e histórico de conclusão guardados no `localStorage` do navegador.
- Confirmação antes de adicionar pontos.
- Reset da demonstração.

## Limitações importantes
- Pontos são fictícios e não têm valor monetário.
- Não há anúncios reais, patrocinadores, cadastro, backend, pagamentos ou saques.
- O saldo fica apenas no navegador/dispositivo e pode ser apagado pelo usuário.
- Não publique como se oferecesse ganhos reais.

## Para evoluir para um serviço real
- Definir uma entidade/estrutura legal e termos de uso e privacidade.
- Encontrar anunciantes e parceiros que autorizem expressamente campanhas com recompensas.
- Construir backend, autenticação, validação de missões e prevenção de fraude.
- Definir orçamento e limites de recompensas com base em receita efetivamente recebida.
- Integrar um provedor de pagamentos e testar saques somente depois de financiar a carteira.
- Cumprir legislação brasileira, proteção de dados e regras de idade aplicáveis.

Este protótipo não inclui nem simula receita, pagamentos ou saques reais.
